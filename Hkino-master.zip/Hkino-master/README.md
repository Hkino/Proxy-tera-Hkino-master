-------------------------------------------

| Commands | description |
| ------ | ------ |
| hk x y z | téléporte au coordonée indiquez|
| hk save/s <nom> | enregistre les coordonées |
| hk go <nom> | téléporte vers une zone précédemment enregistrée |
| hk supr/remove <nom> | suprime une location |
| hk go <distance> | téléporte a la distance indiquer
| tp back | revien en arrière |
| tp up <altitude> | téléporte en haut |
| tp down <altitude> | téléporte en bas |
| tp location/coord | donne vos coordonées actuel|

if you don't understand everything 
discord : Hkino#2163
-------------------------------------------